package datebook.agenda;

import datebook.util.*;

public class Event {
	Time start;
	AnotherClass obj;

}