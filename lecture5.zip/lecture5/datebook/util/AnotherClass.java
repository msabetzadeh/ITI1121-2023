package datebook.util;

public class AnotherClass {

	Time start;
}