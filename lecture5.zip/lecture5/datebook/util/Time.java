package datebook.util;

class Time {

}