public class TestCounter{

	public static void main (String args[]) {
	
		Counter counter1 = new Counter();
		
		counter1.value++;
				
		System.out.println(counter1.getValue());
		
		for (int i = 0; i < 5; i++) {
			counter1.increment();
			System.out.println(counter1.getValue());
		}
	}
}